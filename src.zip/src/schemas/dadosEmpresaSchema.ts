import { z } from 'zod';

const requiredString = (field: string) => z.string({ required_error: `${field} é obrigatório.` }).min(1, `${field} é obrigatório.`);

const ieSchema = z.object({
  id: z.string().uuid().optional().nullable(),
  uf: z.string().optional(),
  ie: z.string().optional(),
});

export const dadosEmpresaSchema = z.object({
  id: z.string().uuid().optional().nullable(),
  razaoSocial: requiredString('Razão Social').max(120, 'Máximo de 120 caracteres.'),
  nomeCompleto: z.string().max(120, 'Máximo de 120 caracteres.').optional().nullable(),
  fantasia: z.string().max(60, 'Máximo de 60 caracteres.').optional().nullable(),

  endereco: z.object({
    cep: z.string().optional().nullable(),
    logradouro: z.string().optional().nullable(),
    numero: z.string().optional().nullable(),
    semNumero: z.boolean().optional(),
    complemento: z.string().optional().nullable(),
    bairro: z.string().optional().nullable(),
    cidade: z.string().optional().nullable(),
    uf: z.string().optional().nullable(),
  }),

  contato: z.object({
    fone: z.string().optional().nullable(),
    fax: z.string().optional().nullable(),
    celular: z.string().optional().nullable(),
    email: z.string().email('E-mail inválido.').or(z.literal('')).optional().nullable(),
    website: z.string().url('URL inválida.').or(z.literal('')).optional().nullable(),
  }),

  regime: z.object({
    segmento: z.string().optional().nullable(),
    tipoPessoa: z.enum(['PJ', 'PF', 'Estrangeiro']).default('PJ'),
    cnpj: z.string().optional().nullable(),
    ie: z.string().optional().nullable(),
    ieIsento: z.boolean().optional(),
    im: z.string().optional().nullable(),
    cnae: z.string().optional().nullable(),
    crt: z.string().optional().nullable(),
    cpf: z.string().optional().nullable(),
  }).superRefine((data, ctx) => {
    if (data.tipoPessoa === 'PJ' && (!data.cnpj || data.cnpj.replace(/\D/g, '').length !== 14)) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'CNPJ é obrigatório e deve ser válido.', path: ['cnpj'] });
    }
    if (data.tipoPessoa === 'PF' && (!data.cpf || data.cpf.replace(/\D/g, '').length !== 11)) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'CPF é obrigatório e deve ser válido.', path: ['cpf'] });
    }
  }),

  substitutosTributarios: z.array(ieSchema).optional(),

  preferenciasContato: z.object({
    comoChamar: z.string().max(60, 'Máximo de 60 caracteres.').optional().nullable(),
    canais: z.string().optional().nullable(),
  }).optional(),

  administrador: z.object({
    nome: z.string().max(120, 'Máximo de 120 caracteres.').optional().nullable(),
    email: z.string().email('E-mail inválido.').optional().nullable(),
    celular: z.string().optional().nullable(),
  }).optional(),

  logoUrl: z.string().optional().nullable(),
});

export type DadosEmpresaFormData = z.infer<typeof dadosEmpresaSchema>;
