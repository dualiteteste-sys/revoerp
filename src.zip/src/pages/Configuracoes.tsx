import SettingsRoutes from './configuracoes/index';
export default SettingsRoutes;
