export interface DREMensal {
  ano: number;
  mes: number;
  mes_nome: string;
  receita: number;
  despesa: number;
  resultado: number;
}
