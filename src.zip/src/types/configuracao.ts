import { IEntity } from './base';

export interface Configuracao extends IEntity {
  chave: string;
  valor: any; // JSONB
  descricao?: string;
}
